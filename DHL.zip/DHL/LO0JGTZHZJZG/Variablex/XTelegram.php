<?php
// by https://t.me/X911_tools

// INFO EMAIL
$to = "Your_Email";

// INFO TELEGRAM
$token = "5178286987:AAHZgOIhf8ueeCU8YPt3ySIN9JVb2wVwMyc"; // Telegram token 
$chat_id = "1925302575"; // Chat Id Telegram
?>